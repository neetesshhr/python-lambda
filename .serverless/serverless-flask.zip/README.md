this is initial
